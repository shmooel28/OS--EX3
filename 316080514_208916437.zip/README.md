# OS--EX3



https://github.com/denehs/unix-domain-socket-example/blob/master/server.c
https://www.tack.ch/unix/network/sockets/udpv6.shtml

https://stackoverflow.com/questions/26582920/mmap-memcpy-to-copy-file-from-a-to-b