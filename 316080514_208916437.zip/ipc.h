#ifndef IPC_H
#define IPC_H

#define CLIENT_SOCK_FILE "client.sock"
#define SERVER_SOCK_FILE "server.sock"

#endif